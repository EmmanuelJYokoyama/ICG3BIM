﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoICG3bim
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        int coluna = 0;
        int linha = 0;
        bool verf = false;
        float area = 0;
        Color cor;
        Bitmap imgCozinha = new Bitmap("C:\\Users\\emman\\Pictures\\Imagem_A.jpg");
        Bitmap imgPanela = new Bitmap("C:\\Users\\emman\\Pictures\\Panela.jpg");

        private void button1_Click(object sender, EventArgs e)
        {
            verf = true;
            coluna = imgCozinha.Width; // O número colunas 
            linha = imgCozinha.Height; // O número de linhas
            Bitmap imgnova = new Bitmap(coluna, linha);
            cor = new Color();
            for (int i = 0; i <= coluna - 1; i++)
            {
                for (int j = 0; j <= linha - 1; j++)
                {
                    double r = imgCozinha.GetPixel(i, j).R;
                    double g = imgCozinha.GetPixel(i, j).G;
                    double b = imgCozinha.GetPixel(i, j).B;

                    double K = r * 0.3 + g * 0.59 + b * 0.11;

                    cor = Color.FromArgb((int)K, (int)K, (int)K);
                    imgnova.SetPixel(i, j, cor);

                }
            }

            imgnova.Save("TESTE1.jpg");
            pictureBox1.Image = imgnova;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {


        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            verf = true;
           
            coluna = imgPanela.Width; // O número colunas 
            linha = imgPanela.Height; // O número de linhas
            Bitmap imgnova = new Bitmap(coluna, linha);
            cor = new Color();
            for (int i = 0; i <= coluna - 1; i++)
            {
                for (int j = 0; j <= linha - 1; j++)
                {
                    int r = imgPanela.GetPixel(i, j).R;
                    int g = imgPanela.GetPixel(i, j).G;
                    int b = imgPanela.GetPixel(i, j).B;

                    if (r >= 230 && g >= 230 && b != 255)
                    {
                        imgnova.SetPixel(i, j, Color.FromArgb(0, 0, 0, 0));
                    }
                    else
                    {
                        cor = Color.FromArgb(r, g, b);
                        imgnova.SetPixel(i, j, cor);
                    }

                }
            }
            pictureBox2.Image = imgnova;
            imgnova.Save("TESTE3.jpg");
            
            pictureBox3.Image = imgnova;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = imgCozinha;
            pictureBox2.Image = imgPanela;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            verf = true;
            coluna = imgCozinha.Width; // O número colunas 
            linha = imgCozinha.Height; // O número de linhas
            Bitmap imgnova = new Bitmap(coluna, linha);
            cor = new Color();
            for (int i = 0; i <= coluna - 1; i++)
            {
                for (int j = 0; j <= linha - 1; j++)
                {
                    double r = imgCozinha.GetPixel(i, j).R;
                    double g = imgCozinha.GetPixel(i, j).G;
                    double b = imgCozinha.GetPixel(i, j).B;

                    double K = r * 0.3 + g * 0.59 + b * 0.11;

                    if (K >= 127)
                        K = 255;
                    else
                        K = 0;

                    cor = Color.FromArgb((int)K, (int)K, (int)K);
                    imgnova.SetPixel(i, j, cor);

                }
            }

            imgnova.Save("TESTE2.jpg");
            pictureBox1.Image = imgnova;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = true;
            pictureBox3.BackColor = Color.Transparent;

        }
    }
}
